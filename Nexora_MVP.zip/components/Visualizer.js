import { useRef, useEffect } from "react";

export default function Visualizer({ audioRef }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    let animationId;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const t = Date.now() * 0.002;
      for (let i = 0; i < 120; i++) {
        ctx.fillStyle = `hsl(${(t * 50 + i * 4) % 360}, 80%, 60%)`;
        ctx.beginPath();
        ctx.arc(
          Math.sin(t + i) * 200 + canvas.width / 2,
          Math.cos(t + i * 0.5) * 200 + canvas.height / 2,
          Math.random() * 4,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }
      animationId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationId);
  }, []);

  return <canvas ref={canvasRef} width={800} height={500} style={{ display: "block", margin: "40px auto", borderRadius: 12 }} />;
}
