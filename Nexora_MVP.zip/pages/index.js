import { useState } from "react";
import Player from "../components/Player";

export default function Home() {
  const [mode, setMode] = useState("fluir");

  return (
    <div style={{ minHeight: "100vh", background: "#050505", color: "white", fontFamily: "sans-serif" }}>
      <h1 style={{ textAlign: "center", paddingTop: 20 }}>NEXORA</h1>
      <p style={{ textAlign: "center", opacity: 0.7 }}>Um estado de liberdade criativa</p>

      <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 20 }}>
        <button onClick={() => setMode("fluir")}>Fluir</button>
        <button onClick={() => setMode("criar")}>Criar</button>
      </div>

      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: 30 }}>
        <Player mode={mode} />
      </div>

      <footer style={{ textAlign: "center", padding: 20, opacity: 0.4 }}>
        © Nexora – Arte • Comunidade • Liberdade
      </footer>
    </div>
  );
}
