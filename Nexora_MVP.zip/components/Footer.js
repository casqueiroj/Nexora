export default function Footer() {
  return (
    <footer style={{ textAlign: "center", padding: 20, opacity: 0.5, background: "#111111", color: "white" }}>
      © Nexora – Arte • Comunidade • Liberdade
    </footer>
  );
}
