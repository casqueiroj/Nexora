import Player from "../components/Player";

export default function Create() {
  return (
    <div style={{ minHeight: "100vh", background: "#050505", color: "white", fontFamily: "sans-serif", textAlign: "center", paddingTop: 20 }}>
      <h1>Modo Criar</h1>
      <p>Experimenta sons, cria vídeos únicos e mergulha na tua liberdade criativa.</p>
      <Player mode="criar" />
    </div>
  );
}
