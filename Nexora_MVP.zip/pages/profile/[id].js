import { useRouter } from "next/router";

export default function Profile() {
  const router = useRouter();
  const { id } = router.query;

  return (
    <div style={{ minHeight: "100vh", background: "#050505", color: "white", fontFamily: "sans-serif", textAlign: "center", paddingTop: 20 }}>
      <h1>Perfil de {id}</h1>
      <p>Aqui poderás ver as criações do artista ou ouvinte.</p>
    </div>
  );
}
