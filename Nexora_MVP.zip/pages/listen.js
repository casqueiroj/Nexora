import Player from "../components/Player";

export default function Listen() {
  return (
    <div style={{ minHeight: "100vh", background: "#050505", color: "white", fontFamily: "sans-serif", textAlign: "center", paddingTop: 20 }}>
      <h1>Modo Fluir</h1>
      <p>Ouve música, relaxa e entra no teu estado de liberdade criativa.</p>
      <Player mode="fluir" />
    </div>
  );
}
