import Link from "next/link";

export default function Navbar() {
  return (
    <nav style={{ display: "flex", justifyContent: "center", gap: 20, padding: 20, background: "#111111" }}>
      <Link href="/">Home</Link>
      <Link href="/listen">Fluir</Link>
      <Link href="/create">Criar</Link>
    </nav>
  );
}
