import { useRef, useState } from "react";
import Visualizer from "./Visualizer";

export default function Player({ mode }) {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);

  const togglePlay = () => {
    if (!audioRef.current) return;
    playing ? audioRef.current.pause() : audioRef.current.play();
    setPlaying(!playing);
  };

  return (
    <div style={{ textAlign: "center" }}>
      <audio ref={audioRef} src="/sounds/dnb-loop.mp3" loop />
      <button onClick={togglePlay}>{playing ? "Parar" : "Tocar"}</button>
      {mode === "criar" && <Visualizer audioRef={audioRef} />}
    </div>
  );
}
